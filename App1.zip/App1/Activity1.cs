﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App1
{
    [Activity(Label = "Activity1")]
    public class Activity1 : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.add_main);

            Core.shoppingList s = new Core.shoppingList();
            Button translateButton = FindViewById<Button>(Resource.Id.add);
            EditText ed =  FindViewById<EditText>(Resource.Id.et1);
            
            translateButton.Click += (sender, e) =>
            {
                // Go to the new page.
                s.addToList(ed.Text);
                var intent = new Intent(this, typeof(MainActivity));
                StartActivity(intent);
            };

        }
    }
}