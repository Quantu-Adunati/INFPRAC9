﻿using System.Text;
using System;
using System.Collections.Generic;

namespace Core
{
    public  class shoppingList
    {
        public static List<GroceryItem> listToShow { get; set; }
        public class GroceryItem
        {
            public String Name { get; set; }
        }
        public String getList()
        {
            string temp = "";
            foreach(GroceryItem e in listToShow)
            {
                temp += (e.Name);
                temp += "\n";
            }
            return temp;
        }
        public void addToList(String s)
        {
            GroceryItem e = new GroceryItem();
            e.Name = s;
            listToShow.Add(e);
        }
    }
}